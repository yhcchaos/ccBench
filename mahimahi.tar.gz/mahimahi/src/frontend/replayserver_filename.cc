#include "config.h"

const char *replayserver_filename = REPLAYSERVER;
